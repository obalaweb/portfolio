<?php  
  $server = 'localhost';
  $username = 'root';
  $password = '';
  $dbtable = 'blog_body';
  
  $conn = mysqli_connect($server, $username, $password, $dbtable);